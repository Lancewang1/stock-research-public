/* Entry points joining the independent model, the event review and the v9 charts. */
function initializeV11(){
  const fmt=x=>Number.isFinite(x)?x.toLocaleString('en-US',{maximumFractionDigits:1}):'—';
  const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function overview(model){const year=model.annual.find(r=>r.period==='2027');$('#studyOverview').innerHTML=`<div class="study-overview"><div class="study-line"><div><div class="cl-kicker">研究快照 · ${escape(REVIEW_DATA.asOf)} / 行情 · ${escape(REVIEW_DATA.marketAsOf)}</div><h2>GOOGL：回撤中的预期变化，与Cloud收入驱动</h2></div><div class="study-links"><button data-study="review">最近回撤 · 事件时间线</button><button data-study="cloud">Cloud Revenue · 可编辑模型</button></div></div><p>${escape(REVIEW_DATA.summary)}</p><p class="cl-muted">当前MS基准 / 用户情景：2027 Cloud收入 <b>${fmt(year?.cloudRevenueBn)}bn</b>。客户预算、Google份额、上线容量与收入单价均可调整；金额为研究情景，不是公司指引。</p></div>`;$('#studyOverview').querySelectorAll('[data-study]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.study==='cloud'){setView('forecast');history.replaceState(null,'','#cloud');WB.openModelDetail('cloud');}else{setView('chart');setTab(3);history.replaceState(null,'','#review');$('#wbResearch').scrollIntoView({behavior:'smooth',block:'start'});}}));}
  window.CloudApp=window.CloudUI.init($('#cloudLab'),CLOUD_DATA,CLM,{onChange:overview,onApply:model=>WB.applyCloudForecast(model.quarters),evidence:(key,period)=>WB.modelEvidence(key,period)});
  const box=document.createElement('div');box.className='box';box.innerHTML='<h3>近期回撤的公司事件</h3><p class="note">QQQ与XLC解释共同市场背景；财报、客户采购、盈利修订和估值分歧请查看按日期连接的事件复盘。</p><button class="chip" id="goEventReview">查看10—11月事件时间线 →</button>';$('#p2 .col').prepend(box);$('#goEventReview').addEventListener('click',()=>{setTab(3);$('#wbResearch').scrollIntoView({behavior:'smooth'});});
  setTab(3);WB.focusCase();

}
